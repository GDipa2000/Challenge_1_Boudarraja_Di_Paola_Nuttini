#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "include/stb_image.h"
#include "include/stb_image_write.h"

#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <iostream>
#include <random>
#include <fstream>

//#include <lis.h>
using namespace Eigen;
using namespace std;
void vectorToImage(const VectorXd& vector, int rows, int cols, const std::string& outputFilename) {
    // Verifica che la dimensione del vettore corrisponda alle dimensioni dell'immagine
    if (vector.size() != rows * cols) {
        std::cerr << "Dimensione del vettore non corrisponde alle dimensioni dell'immagine!" << std::endl;
        return;
    }

    // Crea un array per memorizzare i dati dell'immagine
    unsigned char* image = new unsigned char[rows * cols];

    // Copia i valori dal vettore all'array dell'immagine
    for (int i = 0; i < rows * cols; ++i) {
        image[i] = static_cast<unsigned char>(std::clamp(vector(i), 0.0, 255.0));
    }

    // Salva l'immagine utilizzando stb_image_write
    if (stbi_write_png(outputFilename.c_str(), cols, rows, 1, image, cols) == 0) {
        std::cerr << "Errore nel salvataggio dell'immagine: " << outputFilename << std::endl;
    } else {
        std::cout << "Immagine salvata con successo in: " << outputFilename << std::endl;
    }

    // Libera la memoria allocata per l'immagine
    delete[] image;
}


//Funzione per caricare un vettore da un file.txt
VectorXd loadVectorFromMtx(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        exit(EXIT_FAILURE);
    }

    string line;
    // Ignora i commenti all'inizio del file
    while (getline(file, line)) {
        if (line[0] != '%') {
            break;
        }
    }

    // Leggi la dimensione del vettore dalla prima linea non-commento
    stringstream ss(line);
    int size;
    ss >> size;

    VectorXd vector(size);

    int index;
    double value;
    while (file >> index >> value) {
        vector(index - 1) = value;  // Assumendo che gli indici siano 1-based
    }

    file.close();
    return vector;
}

// Funzione per salvare un vettore in formato .txt
void saveVectorToMtx(const VectorXd& vector, const std::string& filename) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Errore nell'apertura del file " << filename << std::endl;
        return;
    }

    for (int i = 0; i < vector.size(); ++i) {
        file << vector(i) << "\n";
    }

    file.close();
}
// Funzione per salvare una matrice sparsa in formato Matrix Market (.mtx)
void saveMatrixToMtx(const SparseMatrix<double>& matrix, const std::string& filename) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Errore nell'apertura del file " << filename << std::endl;
        return;
    }

    file << "%%MatrixMarket matrix coordinate real general\n";
    file << matrix.rows() << " " << matrix.cols() << " " << matrix.nonZeros() << "\n";

    for (int k = 0; k < matrix.outerSize(); ++k) {
        for (SparseMatrix<double>::InnerIterator it(matrix, k); it; ++it) {
            file << it.row() + 1 << " " << it.col() + 1 << " " << it.value() << "\n";
        }
    }

    file.close();
}

// funzione usata per la creazione del kernel di convoluzione A. richiede come argomenti il numero di righe, il numero di colonne e la matrice del kernel
SparseMatrix<double> createConvolutionMatrix(int rows, int cols, const Matrix3d& kernel) {
    int totalSize = rows * cols;
    SparseMatrix<double> A1(totalSize, totalSize);
    std::vector<Triplet<double>> tripletList;

    // Creazione della matrice A di convoluzione
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            int index = i * cols + j;

            // Applicazione del kernel
            for (int ki = -1; ki <= 1; ++ki) {
                for (int kj = -1; kj <= 1; ++kj) {
                    int neighborRow = i + ki;
                    int neighborCol = j + kj;

                    // Check that neighbors are within the image
                    if (neighborRow >= 0 && neighborRow < rows && neighborCol >= 0 && neighborCol < cols) {
                        int neighborIndex = neighborRow * cols + neighborCol;
                        tripletList.push_back(Triplet<double>(index, neighborIndex, kernel(ki + 1, kj + 1)));
                    }
                }
            }
        }
    }

    A1.setFromTriplets(tripletList.begin(), tripletList.end());
    return A1;
}

// Funzione per l'applicazione della convoluzione e la conversione in matrice. Richiede la matrice di convoluzione A, il vettore v e le dimensioni della matrice
MatrixXd applyConvolutionAndConvert(const SparseMatrix<double>& A, const VectorXd& v, int rows, int cols) {
    // Applicazione della convoluzione
    VectorXd smoothedImageVector = A * v;

    // Riporta a matrice
    MatrixXd smoothedImage(rows, cols);
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            int index = i * cols + j;
            // Ensure the value is between 0 and 255
            smoothedImage(i, j) = std::max(0.0, std::min(255.0, smoothedImageVector(index)));
        }
    }
    return smoothedImage;
}

// Funzione di debug che riporta i dati statistici della matrice
void printMatrixStatistics(const SparseMatrix<double>& A) {
    int nonZeroCount = A.nonZeros();
    long long totalElements = static_cast<long long>(A.rows()) * A.cols();
    double sparsity = (1.0 - static_cast<double>(nonZeroCount) / totalElements) * 100.0;

    cout << "Numero di elementi non zero: " << nonZeroCount << endl;
    cout << "Numero totale di elementi: " << totalElements << endl;
    cout << "Sparsità: " << sparsity << "%" << endl;
}

int main(int argc, char* argv[]) {
    // Caricamento dell'immagine
    int width, height, channels;
    unsigned char* img = stbi_load(IMAGE_PATH, &width, &height, &channels, STBI_grey);
    if (img == nullptr) {
        cerr << "Errore nel caricamento dell'immagine!" << endl;
        return -1;
    }

    int rows = height;
    int cols = width;
    cout << "Size of the matrix: " << rows << " x " << cols << endl;

    // Conversione dell'immagine in una matrice di Eigen
    MatrixXd imgMatrix(rows, cols);
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            imgMatrix(i, j) = img[i * cols + j];
        }
    }

    // Introduzione del disturbo nell'immagine
    unsigned char* noisyImg = new unsigned char[rows * cols];
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(-50, 50);
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            noisyImg[i * cols + j] = std::clamp(img[i * cols + j] + dis(gen), 0, 255);
        }
    }

    // Salvataggio dell'immagine rumorosa nel file noisy_image.png
    stbi_write_png("noisy_image.png", cols, rows, 1, noisyImg, cols);

    // Riformula l'immagine originale come vettore v
    VectorXd v = VectorXd::Zero(rows * cols);
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            v(i * cols + j) = img[i * cols + j];
        }
    }

    // Riformula l'immagine rumorosa come vettore w
    VectorXd w = VectorXd::Zero(rows * cols);
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            w(i * cols + j) = noisyImg[i * cols + j];
        }
    }

    // Verifica delle dimensioni dei vettori
    std::cout << "Size of vector v: " << v.size() << std::endl;
    std::cout << "Size of vector w: " << w.size() << std::endl;
    
    saveVectorToMtx(w, "vector_w.Mtx");

    // Calcolo della norma euclidea del vettore v
    double euclideanNormV = v.norm();
    double euclideanNormW = w.norm();
    std::cout << "Euclidean norm of vector v: " << euclideanNormV << std::endl;
    std::cout << "Euclidean norm of vector w: " << euclideanNormW << std::endl;

    // Definizione del kernel di smoothing 3x3 H_av2
    Matrix3d smoothingKernel;
    smoothingKernel << 1, 1, 1,
                       1, 1, 1,
                       1, 1, 1;
    smoothingKernel /= 9.0;

    // Creazione della matrice di convoluzione A1
    SparseMatrix<double> A1 = createConvolutionMatrix(rows, cols, smoothingKernel);

    // Stampa le statistiche della matrice A1
    printMatrixStatistics(A1);

    // Applicazione della convoluzione e conversione in matrice sulla immagine rumorosa A1 * w
    MatrixXd smoothedImageMatrix = applyConvolutionAndConvert(A1, w, rows, cols);

    // Conversione della matrice Eigen ottenuta dalla applicazione della convoluzione A1 in array
    unsigned char* smoothedImage = new unsigned char[rows * cols];
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            smoothedImage[i * cols + j] = static_cast<unsigned char>(smoothedImageMatrix(i, j));
        }
    }

    // Salvataggio della immagine smoothed
    stbi_write_png("smoothed_image.png", cols, rows, 1, smoothedImage, cols);

    // Definizione del kernel di sharpening 3x3 H_sh2
    Matrix3d sharpeningKernel;
    sharpeningKernel << 0, -3, 0,
                        -1, 9, -3,
                        0, -1, 0;

    // Creazione della matrice di convoluzione A2
    SparseMatrix<double> A2 = createConvolutionMatrix(rows, cols, sharpeningKernel);

    // Stampa le statistiche della matrice A2
    printMatrixStatistics(A2);
    // Salva la matrice di convoluzione A2 in un file .mtx
    saveMatrixToMtx(A2, "convolution_matrix_A2.mtx");

    // Controlla se la matrice A2 è simmetrica
    bool isSymmetricA2 = A2.isApprox(A2.transpose());
    std::cout << "Is A2 symmetric? " << (isSymmetricA2 ? "Yes" : "No") << std::endl;

    // Applicazione del filtro di sharpening all'immagine originale
    MatrixXd sharpenedImageMatrix = applyConvolutionAndConvert(A2, v, rows, cols);

    // Conversione della matrice Eigen ottenuta dalla applicazione della convoluzione A2 in array
    unsigned char* sharpenedImage = new unsigned char[rows * cols];
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            sharpenedImage[i * cols + j] = static_cast<unsigned char>(sharpenedImageMatrix(i, j));
        }
    }

    // Salvataggio dell'immagine sharpened
    stbi_write_png("sharpened_image.png", cols, rows, 1, sharpenedImage, cols);

    // Creazione del kernel di edge detection 3x3 H_lap
    Matrix3d laplacianKernel;
    laplacianKernel << 0, -1, 0,
                       -1, 4, -1,
                       0, -1, 0;

    // Creazione della matrice di convoluzione A3
    SparseMatrix<double> A3 = createConvolutionMatrix(rows, cols, laplacianKernel);

    // Stampa le statistiche della matrice A3
    std::cout<<" Numero righe matrice A3: "<<A3.rows()<<std::endl;
    std::cout<<" Numero colonne matrice A3: "<<A3.cols()<<std::endl;
    printMatrixStatistics(A3);

    // Controlla se la matrice A3 è simmetrica
    bool isSymmetricA3 = A3.isApprox(A3.transpose());
    std::cout << "Is A3 symmetric? " << (isSymmetricA3 ? "Yes" : "No") << std::endl;

    // Applicazione del filtro di edge detection all'immagine originale
    MatrixXd edgeDetectedImageMatrix = applyConvolutionAndConvert(A3, v, rows, cols);

    // Conversione della matrice Eigen ottenuta dalla applicazione della convoluzione A3 in array
    unsigned char* edgeDetectedImage = new unsigned char[rows * cols];
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            edgeDetectedImage[i * cols + j] = static_cast<unsigned char>(edgeDetectedImageMatrix(i, j));
        }
    }

    // Salvataggio dell'immagine edge detected
    stbi_write_png("edge_detected_image.png", cols, rows, 1, edgeDetectedImage, cols);

    // Cleanup
    stbi_image_free(img);
    delete[] noisyImg;
    delete[] smoothedImage;
    delete[] sharpenedImage;
    delete[] edgeDetectedImage;
    // Create identity matrix I
    SparseMatrix<double> I(rows * cols, rows * cols);
I.setIdentity();

// Form the matrix I + A3
SparseMatrix<double> I_plus_A3 = I + A3;
 // Uso del precondizionatore IncompleteCholesky
    IncompleteCholesky<double> precond;
    precond.compute(I_plus_A3);

// Use an iterative solver to solve (I + A3)y = w
    ConjugateGradient<SparseMatrix<double>, Lower|Upper, IncompleteCholesky<double>> solver;
    solver.setTolerance(1e-10);
    
    solver.setTolerance(1e-10);
    solver.compute(I_plus_A3);
    VectorXd y = solver.solve(w);
    
/*ConjugateGradient<SparseMatrix<double>, Lower|Upper, IncompleteCholesky<double>> solver;
solver.setTolerance(1e-10);
solver.compute(I_plus_A3);
solver.setMaxIterations(1000);
VectorXd y = solver.solveWithGuess(w, precond);*/

// Report iteration count and final residual
std::cout << "Iteration count: " << solver.iterations() << std::endl;
std::cout << "Final residual: " << solver.error() << std::endl;

// Convert the solution vector y back to an image
MatrixXd yMatrix(rows, cols);
for (int i = 0; i < rows; ++i) {
    for (int j = 0; j < cols; ++j) {
        int index = i * cols + j;
        yMatrix(i, j) = std::max(0.0, std::min(255.0, y(index)));
    }
}

// Convert Eigen matrix back to an array of unsigned char
unsigned char* yImage = new unsigned char[rows * cols];
for (int i = 0; i < rows; ++i) {
    for (int j = 0; j < cols; ++j) {
        yImage[i * cols + j] = static_cast<unsigned char>(yMatrix(i, j));
    }
}

// Save the image using stb_image_write
stbi_write_png("solution_image.png", cols, rows, 1, yImage, cols);
delete[] yImage;
/*
    in questa sezione viene caricato il file soluzioneChalleng.mtx il quale deve essere convertito 
    da file mtx a vettore, successivamente il vettore viene poi convertito in formato immagine 
    nel file "immagineLis.png"
*/
VectorXd lis_Vector = loadVectorFromMtx(SOLUTION_PATH);


//now I save the reconstruct
vectorToImage(lis_Vector, rows, cols, "immagineLis.png");

    return 0;
}
